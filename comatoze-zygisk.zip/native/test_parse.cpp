#include <cstdio>
#include "spoof_conf.h"
static int P = 0, F = 0;
#define CHK(name, cond) do { if (cond) { P++; } else { F++; printf("  GAGAL %s\n", name); } } while (0)
int main() {
    SpoofCfg c;
    // baris penuh persis seperti yang ditulis spoofapp_add (preset RedMagic 11 Pro+ + chip Snapdragon 8 Elite Gen 5)
    CHK("penuh", parse_spoof_line("com.miHoYo.GenshinImpact|rm11p|nubia|NX809J|1|1|qcom|canoe|QTI|SM8850", c));
    CHK("pkg", c.pkg == "com.miHoYo.GenshinImpact"); CHK("man", c.man == "nubia"); CHK("model", c.model == "NX809J");
    CHK("on", c.on); CHK("full", c.full); CHK("hw", c.hw == "qcom"); CHK("board", c.board == "canoe"); CHK("socman", c.socman == "QTI"); CHK("socmodel", c.socmodel == "SM8850");
    // chip kosong (spoofapp_add dengan '-' menulis kolom kosong)
    SpoofCfg d; CHK("chip kosong", parse_spoof_line("com.a.b|k|asus|ASUS_AI2501|1|0||||", d)); CHK("full0", !d.full); CHK("hw kosong", d.hw.empty() && d.socmodel.empty());
    // dimatikan
    SpoofCfg e; CHK("off", parse_spoof_line("com.a.b|k|samsung|SM-S938B|0|0|||SAMSUNG|", e) && !e.on);
    // format lama 4 kolom
    SpoofCfg g; CHK("4 kolom", parse_spoof_line("com.a.b|k|Google|Pixel 9 Pro XL", g) && g.on && !g.full && g.model == "Pixel 9 Pro XL");
    // tidak valid
    SpoofCfg h; CHK("karakter aneh", !parse_spoof_line("com.a.b|k|a;b|M|1|0", h)); CHK("kurang kolom", !parse_spoof_line("com.a.b|k|x", h)); CHK("kosong", !parse_spoof_line("", h));
    SpoofCfg i; CHK("chip rusak dibuang", parse_spoof_line("com.a.b|k|a|b|1|0|q;c|ok||", i) && i.hw.empty() && i.board == "ok");
    // pencarian baris
    std::string content = "com.other.app|k|a|b|1|0\ncom.miHoYo.GenshinImpact|rm11p|nubia|NX809J|1|1|qcom|canoe|QTI|SM8850\r\ncom.miHoYo|x|a|b\n", line;
    CHK("cari persis", find_pkg_line(content, "com.miHoYo.GenshinImpact", line) && line.find("rm11p") != std::string::npos && line.back() == '0');
    CHK("awalan tidak cocok", !find_pkg_line(content, "com.miHoYo.Genshin", line));
    CHK("paket lain", find_pkg_line(content, "com.miHoYo", line) && line == "com.miHoYo|x|a|b");
    CHK("tidak ada", !find_pkg_line(content, "com.none", line)); CHK("file kosong", !find_pkg_line("", "com.a", line));
    CHK("proses anak", pkg_of_process("com.x.y:push") == "com.x.y"); CHK("proses utama", pkg_of_process("com.x.y") == "com.x.y");
    printf("LULUS=%d GAGAL=%d\n", P, F);
    return F ? 1 : 0;
}
