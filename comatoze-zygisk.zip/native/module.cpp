// Comatoze Zygisk: spoof per-aplikasi (android.os.Build.*) -- hanya aplikasi yang ada di daftar spoof_apps.
// Alur: preAppSpecialize -> tanya companion (root) baris konfigurasi untuk paket ini -> postAppSpecialize -> tulis field Build lewat JNI.
// Aplikasi lain: modul langsung melepas dirinya (DLCLOSE) sehingga tidak ada beban/efek samping.
#include <android/log.h>
#include <fcntl.h>
#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <string>

#include "spoof_conf.h"
#include "zygisk.hpp"

#define TAG "ComatozeZ"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static const char *CONF = "/data/adb/ultrapower/spoof_apps";

static bool read_full(int fd, void *buf, size_t n) {
    char *p = (char *)buf;
    while (n) { ssize_t r = read(fd, p, n); if (r <= 0) return false; p += r; n -= (size_t)r; }
    return true;
}
static bool write_full(int fd, const void *buf, size_t n) {
    const char *p = (const char *)buf;
    while (n) { ssize_t r = write(fd, p, n); if (r <= 0) return false; p += r; n -= (size_t)r; }
    return true;
}

// ---------- companion: proses root, satu-satunya yang boleh membaca /data/adb ----------
static void companion_handler(int fd) {
    uint32_t n = 0;
    std::string out;
    if (read_full(fd, &n, sizeof(n)) && n > 0 && n <= 256) {
        std::string pkg(n, '\0');
        if (read_full(fd, &pkg[0], n)) {
            FILE *f = fopen(CONF, "re");
            if (f) {
                std::string content; char buf[1024]; size_t r;
                while ((r = fread(buf, 1, sizeof(buf), f)) > 0 && content.size() < (1u << 20)) content.append(buf, r);
                fclose(f);
                find_pkg_line(content, pkg, out);
            }
        }
    }
    uint32_t m = (uint32_t)out.size();
    write_full(fd, &m, sizeof(m));
    if (m) write_full(fd, out.data(), m);
}

static void set_field(JNIEnv *env, jclass cls, const char *name, const std::string &v) {
    if (v.empty()) return;
    jfieldID f = env->GetStaticFieldID(cls, name, "Ljava/lang/String;");
    if (!f) { env->ExceptionClear(); return; }   // mis. SOC_MODEL tidak ada di Android < 12
    jstring s = env->NewStringUTF(v.c_str());
    if (!s) { env->ExceptionClear(); return; }
    env->SetStaticObjectField(cls, f, s);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(s);
}

class ComatozeModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { api_ = api; env_ = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        active_ = false;
        int appid = args->uid % 100000;
        if (appid < 10000 || appid > 19999 || !args->nice_name) { release(); return; }   // hanya aplikasi biasa
        const char *nn = env_->GetStringUTFChars(args->nice_name, nullptr);
        if (!nn) { release(); return; }
        std::string pkg = pkg_of_process(nn);
        env_->ReleaseStringUTFChars(args->nice_name, nn);

        std::string line;
        int fd = api_->connectCompanion();
        if (fd >= 0) {
            uint32_t n = (uint32_t)pkg.size(), m = 0;
            if (write_full(fd, &n, sizeof(n)) && write_full(fd, pkg.data(), n) && read_full(fd, &m, sizeof(m)) && m > 0 && m <= 1024) {
                line.assign(m, '\0');
                if (!read_full(fd, &line[0], m)) line.clear();
            }
            close(fd);
        }
        if (line.empty() || !parse_spoof_line(line, cfg_) || !cfg_.on || cfg_.pkg != pkg) { release(); return; }
        active_ = true;
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!active_) return;
        jclass b = env_->FindClass("android/os/Build");
        if (!b) { env_->ExceptionClear(); LOGI("spoof %s -> GAGAL: kelas Build tidak ditemukan", cfg_.pkg.c_str()); return; }
        set_field(env_, b, "MANUFACTURER", cfg_.man);
        set_field(env_, b, "MODEL", cfg_.model);
        if (cfg_.full) {   // mode lengkap: brand/device/product ikut (brand = produsen, device & product = nama model)
            set_field(env_, b, "BRAND", cfg_.man);
            set_field(env_, b, "DEVICE", cfg_.model);
            set_field(env_, b, "PRODUCT", cfg_.model);
        }
        set_field(env_, b, "HARDWARE", cfg_.hw);
        set_field(env_, b, "BOARD", cfg_.board);
        set_field(env_, b, "SOC_MANUFACTURER", cfg_.socman);
        set_field(env_, b, "SOC_MODEL", cfg_.socmodel);
        env_->DeleteLocalRef(b);
        LOGI("spoof %s -> %s %s (full=%d chip=%s/%s/%s/%s)", cfg_.pkg.c_str(), cfg_.man.c_str(), cfg_.model.c_str(), cfg_.full ? 1 : 0,
             cfg_.hw.empty() ? "-" : cfg_.hw.c_str(), cfg_.board.empty() ? "-" : cfg_.board.c_str(),
             cfg_.socman.empty() ? "-" : cfg_.socman.c_str(), cfg_.socmodel.empty() ? "-" : cfg_.socmodel.c_str());
    }

    void preServerSpecialize(zygisk::ServerSpecializeArgs *) override { release(); }

private:
    void release() { api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY); }
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool active_ = false;
    SpoofCfg cfg_;
};

REGISTER_ZYGISK_MODULE(ComatozeModule)
REGISTER_ZYGISK_COMPANION(companion_handler)
