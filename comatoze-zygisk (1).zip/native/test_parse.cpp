#include <cstdio>
#include <fcntl.h>
#include <cstdlib>
#include "prop_override.h"
#include "spoof_conf.h"
static int P = 0, F = 0;
#define CHK(name, cond) do { if (cond) { P++; } else { F++; printf("  GAGAL %s\n", name); } } while (0)
int main() {
    SpoofCfg c;
    // baris penuh persis seperti yang ditulis spoofapp_add (preset RedMagic 11 Pro+ + chip Snapdragon 8 Elite Gen 5)
    CHK("penuh", parse_spoof_line("com.miHoYo.GenshinImpact|rm11p|nubia|NX809J|1|1|qcom|canoe|QTI|SM8850", c));
    CHK("pkg", c.pkg == "com.miHoYo.GenshinImpact"); CHK("man", c.man == "nubia"); CHK("model", c.model == "NX809J");
    CHK("on", c.on); CHK("full", c.full); CHK("hw", c.hw == "qcom"); CHK("board", c.board == "canoe"); CHK("socman", c.socman == "QTI"); CHK("socmodel", c.socmodel == "SM8850");
    // chip kosong (spoofapp_add dengan '-' menulis kolom kosong)
    SpoofCfg d; CHK("chip kosong", parse_spoof_line("com.a.b|k|asus|ASUS_AI2501|1|0||||", d)); CHK("full0", !d.full); CHK("hw kosong", d.hw.empty() && d.socmodel.empty());
    // dimatikan
    SpoofCfg e; CHK("off", parse_spoof_line("com.a.b|k|samsung|SM-S938B|0|0|||SAMSUNG|", e) && !e.on);
    // format lama 4 kolom
    SpoofCfg g; CHK("4 kolom", parse_spoof_line("com.a.b|k|Google|Pixel 9 Pro XL", g) && g.on && !g.full && g.model == "Pixel 9 Pro XL");
    // tidak valid
    SpoofCfg h; CHK("karakter aneh", !parse_spoof_line("com.a.b|k|a;b|M|1|0", h)); CHK("kurang kolom", !parse_spoof_line("com.a.b|k|x", h)); CHK("kosong", !parse_spoof_line("", h));
    SpoofCfg i; CHK("chip rusak dibuang", parse_spoof_line("com.a.b|k|a|b|1|0|q;c|ok||", i) && i.hw.empty() && i.board == "ok");
    // pencarian baris
    std::string content = "com.other.app|k|a|b|1|0\ncom.miHoYo.GenshinImpact|rm11p|nubia|NX809J|1|1|qcom|canoe|QTI|SM8850\r\ncom.miHoYo|x|a|b\n", line;
    CHK("cari persis", find_pkg_line(content, "com.miHoYo.GenshinImpact", line) && line.find("rm11p") != std::string::npos && line.back() == '0');
    CHK("awalan tidak cocok", !find_pkg_line(content, "com.miHoYo.Genshin", line));
    CHK("paket lain", find_pkg_line(content, "com.miHoYo", line) && line == "com.miHoYo|x|a|b");
    CHK("tidak ada", !find_pkg_line(content, "com.none", line)); CHK("file kosong", !find_pkg_line("", "com.a", line));
    CHK("proses anak", pkg_of_process("com.x.y:push") == "com.x.y"); CHK("proses utama", pkg_of_process("com.x.y") == "com.x.y");

    // ---------- spoof_props ----------
    {
        SpoofCfg a; parse_spoof_line("com.x|gt50p|INFINIX|Infinix X6891|1|1|qcom|canoe|QTI|SM8850", a);
        auto v = spoof_props(a);
        auto get = [&](const std::string &k) { for (auto &kv : v) if (kv.first == k) return kv.second; return std::string("<none>"); };
        CHK("props model", get("ro.product.model") == "Infinix X6891"); CHK("props model system", get("ro.product.system.model") == "Infinix X6891");
        CHK("props vendor man", get("ro.product.vendor.manufacturer") == "INFINIX"); CHK("props full device", get("ro.product.device") == "Infinix_X6891");
        CHK("props full brand", get("ro.product.brand") == "INFINIX"); CHK("props soc", get("ro.soc.model") == "SM8850" && get("ro.soc.manufacturer") == "QTI");
        CHK("props board", get("ro.product.board") == "canoe");
        CHK("TIDAK menyentuh ro.hardware", get("ro.hardware") == "<none>"); CHK("TIDAK menyentuh ro.board.platform", get("ro.board.platform") == "<none>");
        SpoofCfg b; parse_spoof_line("com.x|k|nubia|NX809J|1|0||||", b); auto w = spoof_props(b);
        bool anyfull = false, anychip = false; for (auto &kv : w) { if (kv.first.find(".brand") != std::string::npos || kv.first.find(".device") != std::string::npos) anyfull = true; if (kv.first.find("ro.soc") == 0 || kv.first == "ro.product.board") anychip = true; }
        CHK("tanpa full: tak ada brand/device", !anyfull); CHK("tanpa chip: tak ada ro.soc", !anychip);
    }
    // ---------- override_prop_value: area properti palsu di file, dipetakan MAP_SHARED PROT_READ seperti bionic ----------
    {
        const size_t PS = 4096, N = 3 * PS;
        char path[] = "/tmp/proparea_XXXXXX"; int fd = mkstemp(path); unlink(path);
        std::string img(N, '\0'); for (size_t i = 0; i < N; i++) img[i] = (char)('a' + (i * 7) % 23);
        const size_t off = PS - 40;   // prop_info melintasi batas halaman 0/1: kasus tersulit
        uint32_t ser0 = (8u << 24) | 0x10000u | 1u;   // panjang 8, flag "long", bit dirty: harus dibersihkan
        memcpy(&img[off], &ser0, 4); memset(&img[off + 4], 0, 92); memcpy(&img[off + 4], "ORIGINAL", 8);
        strcpy(&img[off + 96], "ro.product.model");
        const size_t off2 = PS + 200; uint32_t s2 = 5u << 24;
        { char full[96 + 17]; memset(full, 0, sizeof full); memcpy(full, &s2, 4); memcpy(full + 4, "OLDMD", 5); strcpy(full + 96, "ro.soc.model");
          memcpy(&img[off2], full, sizeof full); }
        if (write(fd, img.data(), N) != (ssize_t)N) return 2;
        auto *A = (char *)mmap(nullptr, N, PROT_READ, MAP_SHARED, fd, 0);   // "proses ini"
        auto *B = (char *)mmap(nullptr, N, PROT_READ, MAP_SHARED, fd, 0);   // "proses lain" (zygote/init)
        CHK("map ok", A != MAP_FAILED && B != MAP_FAILED);
        CHK("nama salah ditolak", !override_prop_value(A + off, "ro.product.brand", "x"));
        CHK("tidak berubah setelah ditolak", memcmp(A, img.data(), N) == 0);
        CHK("nilai terlalu panjang ditolak", !override_prop_value(A + off, "ro.product.model", std::string(92, 'z')));
        CHK("nilai kosong ditolak", !override_prop_value(A + off, "ro.product.model", ""));
        CHK("override berhasil", override_prop_value(A + off, "ro.product.model", "Infinix X6891"));
        CHK("nilai baru di A", strcmp(A + off + 4, "Infinix X6891") == 0);
        uint32_t sa; memcpy(&sa, A + off, 4);
        CHK("panjang di serial", (sa >> 24) == 13); CHK("flag long & dirty bersih", (sa & 0x10001u) == 0);
        CHK("nama tetap utuh", strcmp(A + off + 96, "ro.product.model") == 0);
        std::string aa(A, N), bb(B, N);
        CHK("B (proses lain) TIDAK berubah", bb == img);
        bool same = true; for (size_t i = 0; i < N; i++) { if (i >= off && i < off + 96) continue; if (aa[i] != img[i]) same = false; }
        CHK("sisa isi halaman identik", same);
        CHK("override kedua (properti sama) berhasil", override_prop_value(A + off, "ro.product.model", "NX809J") && strcmp(A + off + 4, "NX809J") == 0);
        // file asli tidak ikut berubah (MAP_SHARED tidak tersentuh)
        std::string fl(N, '\0'); if (pread(fd, &fl[0], N, 0) != (ssize_t)N) return 2; CHK("file asli utuh", fl == img);
        // properti di halaman lain (sudah berupa salinan pribadi sejak override pertama karena rentangnya ikut) tetap bisa ditimpa
        CHK("prop tengah halaman", override_prop_value(A + off2, "ro.soc.model", "SM8850") && strcmp(A + off2 + 4, "SM8850") == 0 && strcmp(B + off2 + 4, "OLDMD") == 0);
    }
    printf("LULUS=%d GAGAL=%d\n", P, F);
    return F ? 1 : 0;
}
