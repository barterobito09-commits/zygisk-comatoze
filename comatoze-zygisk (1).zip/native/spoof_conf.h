// Logika murni (tanpa JNI/Zygisk) supaya bisa diuji di komputer biasa.
// Format baris /data/adb/ultrapower/spoof_apps (ditulis oleh skrip `ultrapower spoofapp ...`):
//   paket|key|manufacturer|model|on|full|hardware|board|soc_manufacturer|soc_model
//   on   : 1 aktif / 0 mati (kosong/tidak ada = aktif)
//   full : 1 = ikut ganti BRAND/DEVICE/PRODUCT
//   kolom chip boleh kosong = ikut chip asli. Baris format lama (4 kolom) tetap valid.
#pragma once
#include <string>
#include <utility>
#include <vector>

struct SpoofCfg {
    std::string pkg, key, man, model, hw, board, socman, socmodel;
    bool on = true, full = false;
};

inline std::vector<std::string> split_keep(const std::string &s, char d = '|') {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == d) { out.push_back(cur); cur.clear(); }
        else cur += c;
    }
    out.push_back(cur);
    return out;
}

// sama dengan spoof_valid() di skrip: huruf, angka, spasi, titik, underscore, plus, minus; maks 40
inline bool spoof_value_ok(const std::string &s) {
    if (s.empty() || s.size() > 40) return false;
    for (unsigned char c : s) {
        bool ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
                  c == ' ' || c == '.' || c == '_' || c == '+' || c == '-';
        if (!ok) return false;
    }
    return true;
}

inline bool parse_spoof_line(const std::string &line, SpoofCfg &o) {
    auto f = split_keep(line);
    if (f.size() < 4) return false;
    o.pkg = f[0]; o.key = f[1]; o.man = f[2]; o.model = f[3];
    o.on = !(f.size() >= 5 && f[4] == "0");
    o.full = f.size() >= 6 && f[5] == "1";
    if (f.size() > 6) o.hw = f[6];
    if (f.size() > 7) o.board = f[7];
    if (f.size() > 8) o.socman = f[8];
    if (f.size() > 9) o.socmodel = f[9];
    // nilai yang tidak lolos validasi dibuang (defence-in-depth; file ini ditulis root tetapi tetap divalidasi)
    if (!spoof_value_ok(o.man) || !spoof_value_ok(o.model)) return false;
    if (!o.hw.empty() && !spoof_value_ok(o.hw)) o.hw.clear();
    if (!o.board.empty() && !spoof_value_ok(o.board)) o.board.clear();
    if (!o.socman.empty() && !spoof_value_ok(o.socman)) o.socman.clear();
    if (!o.socmodel.empty() && !spoof_value_ok(o.socmodel)) o.socmodel.clear();
    return true;
}

// cari baris milik paket (kolom pertama persis sama) di isi file
inline bool find_pkg_line(const std::string &content, const std::string &pkg, std::string &line) {
    size_t pos = 0;
    while (pos <= content.size()) {
        size_t e = content.find('\n', pos);
        if (e == std::string::npos) e = content.size();
        std::string l = content.substr(pos, e - pos);
        while (!l.empty() && (l.back() == '\r')) l.pop_back();
        if (l.size() > pkg.size() && l.compare(0, pkg.size(), pkg) == 0 && l[pkg.size()] == '|') { line = l; return true; }
        pos = e + 1;
    }
    return false;
}

// nama proses (nice_name) -> nama paket: "com.x:service" -> "com.x"
inline std::string pkg_of_process(const std::string &proc) {
    size_t c = proc.find(':');
    return c == std::string::npos ? proc : proc.substr(0, c);
}

// Daftar properti yang ditimpa (nama, nilai) untuk satu konfigurasi. Hanya yang ada di perangkat yang benar-benar ditimpa (lihat module.cpp).
// SENGAJA tidak mencakup ro.hardware / ro.board.platform: pemuat driver GPU (EGL/Vulkan) di dalam aplikasi memakainya untuk memilih library.
inline std::vector<std::pair<std::string, std::string>> spoof_props(const SpoofCfg &c) {
    std::vector<std::pair<std::string, std::string>> v;
    static const char *parts[] = {"", "system.", "system_ext.", "vendor.", "odm.", "product."};
    std::string dn = c.model;
    for (auto &ch : dn) if (ch == ' ') ch = '_';
    for (const char *pt : parts) {
        std::string b = std::string("ro.product.") + pt;
        v.push_back({b + "manufacturer", c.man});
        v.push_back({b + "model", c.model});
        if (c.full) {
            v.push_back({b + "brand", c.man});
            v.push_back({b + "device", dn});
            v.push_back({b + "name", dn});
        }
    }
    if (!c.socman.empty()) v.push_back({"ro.soc.manufacturer", c.socman});
    if (!c.socmodel.empty()) v.push_back({"ro.soc.model", c.socmodel});
    if (!c.board.empty()) v.push_back({"ro.product.board", c.board});
    return v;
}
