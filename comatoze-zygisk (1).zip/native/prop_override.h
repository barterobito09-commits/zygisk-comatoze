// Menimpa nilai SATU properti sistem hanya untuk proses ini (per-app, tanpa reboot, tanpa menyentuh properti asli).
// Cara kerja: semua pembaca properti (getprop native, __system_property_get, SystemProperties di Java, Unity/Unreal) membaca area properti
// yang di-mmap dari /dev/__properties__. Halaman yang memuat prop_info itu disalin ke memori anonim pribadi proses ini, nilainya diubah di salinan,
// lalu salinan dipindahkan MENIMPA alamat asli dengan mremap(MREMAP_FIXED) -- atomik, jadi pembaca di thread lain tidak pernah melihat halaman kosong.
// Proses lain (termasuk zygote & init) tetap melihat nilai asli.
// Tata letak bionic prop_info: uint32 serial; char value[92]; char name[]  (name = 96 byte dari awal). Nama divalidasi dulu; tak cocok = tidak diubah.
#pragma once
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include <string>

static const size_t kPropValueMax = 92;

inline bool override_prop_value(void *pi, const char *name, const std::string &val) {
    if (!pi || !name || val.empty() || val.size() >= kPropValueMax) return false;
    char *p = (char *)pi;
    if (strcmp(p + 4 + kPropValueMax, name) != 0) return false;   // tata letak tidak cocok -> jangan sentuh
    uintptr_t ps = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t a = (uintptr_t)p;
    uintptr_t first = a & ~(ps - 1);
    uintptr_t last = (a + 4 + kPropValueMax - 1) & ~(ps - 1);
    size_t len = (size_t)(last - first + ps);
    void *np = mmap(nullptr, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (np == MAP_FAILED) return false;
    memcpy(np, (void *)first, len);
    char *q = (char *)np + (a - first);
    uint32_t ser;
    memcpy(&ser, q, 4);
    memset(q + 4, 0, kPropValueMax);
    memcpy(q + 4, val.data(), val.size());
    ser = ((uint32_t)val.size() << 24) | (ser & 0x00FEFFFEu);   // panjang baru; bit "dirty" (1) dan "long property" (1<<16) dibersihkan
    memcpy(q, &ser, 4);
    if (mprotect(np, len, PROT_READ) != 0) { munmap(np, len); return false; }
    void *r = mremap(np, len, len, MREMAP_MAYMOVE | MREMAP_FIXED, (void *)first);
    if (r == MAP_FAILED) { munmap(np, len); return false; }
    return true;
}
